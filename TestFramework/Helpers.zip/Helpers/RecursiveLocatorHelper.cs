﻿using OpenQA.Selenium;
using System.Diagnostics;

namespace TestFramework.Helpers
{
    public class RecursiveLocatorHelper
    {
        private int depth = 0;

        public IWebElement FindElementRecursive(IWebDriver webDriver, By searchCriteria)
        {
            IWebElement element = null;
            bool found = false;

            depth++;
            while (!found && depth > 0)
            {
                try
                {
                    element = webDriver.FindElement(searchCriteria);
                }
                catch (NoSuchElementException ex)
                {
                    Trace.WriteLine("   Element not found in ctx: " + ex.Message);
                }

                if (null == element)
                {
                    var frames = webDriver.FindElements(By.CssSelector("iframe"));
                    if (frames.Count == 0)
                    {
                        webDriver.SwitchTo().ParentFrame();
                        return element;
                    }

                    foreach (var frame in frames)
                    {
                        if (element == null)
                        {
                            webDriver.SwitchTo().Frame(frame);
                            element = FindElementRecursive(webDriver, searchCriteria);
                        }
                    }
                    if (null == element)
                    {
                        // Finished lookig in the current frame, so go back to the parent.
                        webDriver.SwitchTo().ParentFrame();
                    }
                }

                found = null != element;
                depth--;
            }
            return element;
        }



        public IWebElement FindElementRecursiveDontWork(ISearchContext searchCtx, By searchCriteria)
        {
            var targetLocator = searchCtx as ITargetLocator;
            IWebElement element = null;
            bool found = false;

            while (!found)
            {
                try
                {
                    element = searchCtx.FindElement(searchCriteria);
                }
                catch (NoSuchElementException)
                {
                    Trace.WriteLine("   Element not found in ctx: " + searchCtx.ToString());
                }

                if (null == element)
                {
                    var frames = searchCtx.FindElements(By.CssSelector("iframe"));
                    if (frames.Count == 0) return element;

                    foreach (var frame in frames)
                    {
                        if (element == null)
                            element = FindElementRecursiveDontWork(frame, searchCriteria);
                    }
                }

                found = null != element;
            }
            return element;
        }
    }
}
