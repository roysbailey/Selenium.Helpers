﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestFramework.Helpers
{
    public static class SearchContextExtensions
    {
        public static IWebElement FindElementRecursive(this ISearchContext searchCtx, By searchCriteria)
        {
            var webDriver = searchCtx as IWebDriver;
            webDriver.SwitchTo().DefaultContent();

            var locator = new RecursiveLocatorHelper();
            var element = locator.FindElementRecursive(webDriver, searchCriteria);
            return element;
        }
    }
}
